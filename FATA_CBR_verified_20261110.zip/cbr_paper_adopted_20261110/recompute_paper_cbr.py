"""Recover the original paper's result records and emit a reproducible bundle."""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
from datetime import datetime, timezone

DATASETS = ('TextVQA_Open', 'VQAv2_Open', 'ScienceQA_MC', 'VQAv2_MC')
METHODS = ('VisionZIP', 'VisPruner', 'FlowCut', 'PruMerge')
ALL_METHODS = (*METHODS, 'DivPrune')
OLD_COMMIT = '060c3b0d997eb7513ff5543a9e5224c8bb5014ca'
ORIGINAL_BLOBS = {
    'results/paper/main_llava/caa_eps2_overall_summary.csv': '49bc91e98b39603fbae5b9356ceab4000db38a2e',
    'results/paper/qwen35/QWEN35_4COMP_CBR_CELL_AUDIT.csv': '2bb44164a1e1116680027a26ca8172093428eb98',
    'results/paper/qwen35/QWEN35_4COMP_CBR_BY_COMPRESSOR.csv': '710a578bf223155ccc9b2338c5014bf267509cdf',
    'results/paper/qwen35/QWEN35_4COMP_TABLE7_SR_CBR_AUTHORITATIVE.csv': 'd4ab78303a7636efc38c65c9e9734c3ebdf83946',
}
SCORE_COLUMNS = ('Clean_K576', 'Clean_K192', 'Clean_K128', 'Clean_K64', 'Clean_K32', 'Clean_K16')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows, fields=None):
    rows = list(rows)
    if fields is None:
        fields = list(dict.fromkeys(k for row in rows for k in row))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def number(value):
    result = float(value)
    if not math.isfinite(result) or not 0 <= result <= 1:
        raise ValueError(f'Invalid task score: {value!r}')
    return result


def boolean(value):
    if value in ('True', 'true', '1'):
        return True
    if value in ('False', 'false', '0'):
        return False
    raise ValueError(f'Invalid stored flag: {value!r}')


def percent(n, d):
    return 100*n/d if d else None


def display(value, digits):
    return f'{value:.{digits}f}' if value is not None else 'NA'


class Recovery:
    def __init__(self, args):
        self.args = args
        self.root = Path(args.source_root).resolve()
        self.out = Path(args.output).resolve()
        self.repo = Path(args.history_repo).resolve() if args.history_repo else None
        self.out.mkdir(parents=True, exist_ok=True)
        self.source_records = {}
        self.cells = []
        self.exclusions = []
        self.logs = []
        self.public_updates = {}
        self.hash_checks = []
        self.table_rows = []
        self.raw_cache = {}
        self.input_rows = {}
        self.pair_files = []
        self.internvl_records = []
        self.started = datetime.now(timezone.utc).isoformat()

    def log(self, text):
        self.logs.append(text)
        print(text, flush=True)

    def use(self, path, role):
        p = Path(path).resolve()
        key = str(p)
        if key not in self.source_records:
            self.source_records[key] = {
                'source_path': p.as_posix(), 'sha256': sha(p),
                'bytes': p.stat().st_size, 'roles': role,
            }
        elif role not in self.source_records[key]['roles'].split(';'):
            self.source_records[key]['roles'] += ';' + role
        return self.source_records[key]

    def original(self, rel):
        dest = self.out/'evidence/original_release'/rel
        if self.repo is not None:
            raw = subprocess.check_output([
                self.args.git, '-C', str(self.repo), 'show', OLD_COMMIT+':'+rel,
            ])
        else:
            raw = dest.read_bytes()
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
        blob = ORIGINAL_BLOBS[rel]
        actual_blob = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        assert actual_blob == blob
        self.use(dest, 'restored_original_git_blob')
        self.hash_checks.append({'path': rel, 'commit': OLD_COMMIT, 'git_blob': blob,
                                 'git_blob_verified': True, 'sha256': sha(dest)})
        return list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))

    def raw(self, path, role):
        p = Path(path)
        self.use(p, role)
        if p not in self.raw_cache:
            rows = read_csv(p)
            ids = [r['Image_ID'] for r in rows]
            assert ids and len(ids) == len(set(ids)), p
            for row in rows:
                assert None not in row and row['Image_ID']
                for k, v in row.items():
                    if '_K' in k:
                        number(v)
            self.raw_cache[p] = rows
            self.input_rows[str(p.resolve())] = {row['Image_ID']:i+2 for i,row in enumerate(rows)}
        return self.raw_cache[p]

    def practical(self, rows):
        full = statistics.fmean(number(r['Clean_K576']) for r in rows)
        assert full > 0
        return next(k for k in (16,32,64,128,192,576)
                    if statistics.fmean(number(r[f'Clean_K{k}']) for r in rows)/full >= .8)

    def llava_cell(self, series, attack, method, dataset, path, k, reference=None):
        original = self.raw(path, series)
        clean_path = Path(path)
        if 'Clean_K576' not in original[0]:
            clean_path = self.root/'ultimate_results'/f'ultimate_benchmark_{method}_{dataset}.csv'
            clean = self.raw(clean_path, 'llava_clean_pairing')
        else:
            clean = original
        clean_by = {r['Image_ID']:r for r in clean}
        attack_by = {r['Image_ID']:r for r in original}
        missing = set(clean_by) - set(attack_by)
        extra = set(attack_by) - set(clean_by)
        assert not extra, (path, extra)
        for sample_id in sorted(missing):
            self.exclusions.append({'series':series,'dataset':dataset,'method':method,
                'sample_id':sample_id,'reason':'absent_from_attack_csv','source':Path(path).as_posix()})
        metadata = {'model':'LLaVA-1.5-7B','series':series,'attack':attack,'dataset':dataset,
                    'compressor':method,'budget':str(k)}
        sid = '|'.join(metadata.values())
        paired = []
        for sample_id in sorted(attack_by):
            a = attack_by[sample_id]; c = clean_by[sample_id]
            assert c['Question'] == a['Question'], (path, sample_id, 'question pairing')
            cf,af,cc,ac = [number(z) for z in (c['Clean_K576'],a[attack+'_K576'],c[f'Clean_K{k}'],a[f'{attack}_K{k}'])]
            # Preserve the respective historical producer's stored score policy.
            good = (lambda v: v > 0) if series == 'CAA_eps2' else (lambda v: v >= .9)
            cf_flag,af_flag,cc_flag,ac_flag = (good(v) for v in (cf,af,cc,ac))
            den = cf_flag and af_flag
            num = den and ac < .1
            paired.append({**metadata,'setting_id':sid,'sample_id':sample_id,
                'clean_full_score':cf,'attack_full_score':af,'clean_compressed_score':cc,
                'attack_compressed_score':ac,'clean_full_correct':int(cf_flag),
                'attack_full_correct':int(af_flag),'clean_compressed_correct':int(cc_flag),
                'attack_compressed_correct':int(ac_flag),'denominator_member':int(den),
                'numerator_member':int(num),'attack_compressed_zero':int(ac < .1),
                'source_file':Path(path).relative_to(self.root).as_posix(),
                'source_row':self.input_rows[str(Path(path).resolve())][sample_id],
                'clean_source_file':clean_path.relative_to(self.root).as_posix(),
                'clean_source_row':self.input_rows[str(clean_path.resolve())][sample_id]})
        n = sum(x['numerator_member'] for x in paired)
        d = sum(x['denominator_member'] for x in paired)
        assert 0 <= n <= d <= len(paired) and d > 0
        rate = percent(n,d)
        if reference is not None:
            assert abs(rate-reference) < 1e-10, (sid,rate,reference)
        pair_rel=f'paired_records/llava/{series}/{method}_{dataset}.csv'
        write_csv(self.out/pair_rel, paired)
        self.pair_files.append(pair_rel)
        sr=100*statistics.fmean(x['attack_full_score'] for x in paired)/statistics.fmean(x['clean_full_score'] for x in paired)
        result={**metadata,'setting_id':sid,'sample_count':len(paired),
            'cbr_numerator':n,'cbr_denominator':d,'cbr_percent':rate,
            'sr_percent':sr,'paired_records':pair_rel,'paired_records_sha256':sha(self.out/pair_rel),
            'source_sha256':sha(path),'evidence':'recomputed_sample_records'}
        self.cells.append(result)
        self.log(f'CELL {sid} samples={len(paired)} numerator={n} denominator={d} CBR={rate:.10f}%')
        return result

    def main_llava(self):
        summary=self.root/'ultimate_charts/ADVANCED_METRICS_SUMMARY.csv'
        self.use(summary,'historical_main_20_setting_summary')
        archived=read_csv(summary)
        for a in ('FATA','CAGE'):
            for x in [r for r in archived if r['Attack']==a]:
                pre='ultimate_benchmark' if a=='FATA' else 'cage_pilot'
                path=self.root/'ultimate_results'/f"{pre}_{x['Method']}_{x['Dataset']}.csv"
                self.llava_cell(a,a,x['Method'],x['Dataset'],path,int(x['K_prac']),float(x['CBR (%)']))
        self.original_caa_summary=self.original('results/paper/main_llava/caa_eps2_overall_summary.csv')
        for method in ALL_METHODS:
            for ds in DATASETS:
                ref=next(x for x in archived if x['Attack']=='CAA' and x['Method']==method and x['Dataset']==ds)
                path=self.root/'ultimate_results/ultimate_results'/f'caa_eps2_a1_s100_seed0_{method}_{ds}.csv'
                cell=self.llava_cell('CAA_eps2','CAA',method,ds,path,int(ref['K_prac']))
        for variant in ('attn_only','sem_only'):
            for method in METHODS:
                for ds in DATASETS:
                    path=self.root/'ultimate_results'/f'fata_ablation_{variant}_{method}_{ds}.csv'
                    rr=self.raw(path,'loss_ablation_'+variant)
                    k=self.practical(rr)
                    self.llava_cell('ablation_'+variant,'FATA',method,ds,path,k)
        caa=self.aggregate('CAA_eps2')
        assert abs(caa['cbr_percent']-float(self.original_caa_summary[0]['CBR (%)']))<1e-10

    def aggregate(self,series,methods=None):
        cells=[x for x in self.cells if x['series']==series and (methods is None or x['compressor'] in methods)]
        assert cells
        return {'series':series,'setting_count':len(cells),
            'cbr_percent':statistics.fmean(x['cbr_percent'] for x in cells),
            'sr_percent':statistics.fmean(x['sr_percent'] for x in cells if x.get('sr_percent') is not None) if any(x.get('sr_percent') is not None for x in cells) else '',
            'numerator_sum':sum(x['cbr_numerator'] for x in cells),
            'denominator_sum':sum(x['cbr_denominator'] for x in cells),
            'pooled_percent':percent(sum(x['cbr_numerator'] for x in cells),sum(x['cbr_denominator'] for x in cells)),
            'setting_ids':[x['setting_id'] for x in cells]}

    def qwen(self):
        self.qwen_original=self.original('results/paper/qwen35/QWEN35_4COMP_CBR_CELL_AUDIT.csv')
        self.qwen_original_by_method=self.original('results/paper/qwen35/QWEN35_4COMP_CBR_BY_COMPRESSOR.csv')
        self.qwen_original_table=self.original('results/paper/qwen35/QWEN35_4COMP_TABLE7_SR_CBR_AUTHORITATIVE.csv')
        assert len(self.qwen_original)==16
        for x in self.qwen_original:
            n,d=int(x['N_blind_practical']),int(x['N_stealth'])
            assert n+int(x['N_practical_correct_on_stealth'])==d
            assert 0<=n<=d<=int(x['N_total'])
            rate=percent(n,d)
            assert display(rate,2)==display(float(x['CBR_display_2dp']),2)
            sid='|'.join(['Qwen3.5-9B','Qwen_V6','FATA',x['dataset'],x['method'],x['practical_retention']])
            c={'model':'Qwen3.5-9B','series':'Qwen_V6','attack':'FATA','dataset':x['dataset'],
                'compressor':x['method'],'budget':x['practical_retention'],'setting_id':sid,
                'sample_count':int(x['N_total']),'cbr_numerator':n,'cbr_denominator':d,
                'cbr_percent':rate,'sr_percent':float(x['SR_percent']),
                'evidence':'original_git_integer_counts','source_commit':OLD_COMMIT,
                'source_file':'evidence/original_release/results/paper/qwen35/QWEN35_4COMP_CBR_CELL_AUDIT.csv'}
            self.cells.append(c)
            self.log(f'CELL {sid} samples={c["sample_count"]} numerator={n} denominator={d} CBR={rate:.10f}% integer_count_source=original_git_blob')
        for x in self.qwen_original_table:
            for method in METHODS:
                c=next(z for z in self.cells if z['series']=='Qwen_V6' and z['dataset']==x['Dataset'] and z['compressor']==method)
                assert display(c['cbr_percent'],2)==display(float(x[method+'_CBR_percent']),2)

    def internvl(self):
        candidates=list((self.root/'InternVL3.5模型实验代码').glob('*/*/V5_EXPERIMENT/results/formal'))
        assert len(candidates)==1
        formal=candidates[0]
        original_reports=formal.parents[1]/'reports'
        hashes={x['Path'].split('/formal/')[-1]:x['SHA256'] for x in read_csv(original_reports/'FORMAL_INPUT_FILES.csv')}
        self.use(original_reports/'FORMAL_INPUT_FILES.csv','historical_internvl_input_hashes')
        self.use(original_reports/'cbr.csv','historical_internvl_counts')
        expected={(m,b) for m in ALL_METHODS for b in ('1/3','2/9','1/9','1/18','1/36')}|{('Full','Full')}
        saved=read_csv(original_reports/'cbr.csv')
        for ds in DATASETS:
            path=formal/ds/'sample_results.csv'
            self.use(path,'internvl_v5_formal_sample_records')
            assert sha(path)==hashes[ds+'/sample_results.csv']
            grouped=collections.defaultdict(list)
            with path.open(encoding='utf-8-sig',newline='') as stream:
                for line,x in enumerate(csv.DictReader(stream),2):
                    assert x['dataset']==ds
                    grouped[x['sample_index']].append((line,x))
            assert len(grouped)==1000
            complete={}
            for index,group in grouped.items():
                keys=[(x['compression_method'],x['ratio_label']) for _,x in group]
                if len(group)==26 and set(keys)==expected and all(x['status']=='success' for _,x in group):
                    complete[index]=group
                else:
                    self.exclusions.append({'series':'InternVL_V5','dataset':ds,'method':'all',
                        'sample_id':group[0][1]['image_id'],'reason':'recorded_failed_sample',
                        'source':path.relative_to(self.root).as_posix()})
            assert len(complete)==(998 if ds=='TextVQA_Open' else 1000)
            practical='1/9' if ds.endswith('Open') else '1/18'
            pairs=collections.defaultdict(list)
            for index,group in complete.items():
                records={(x['compression_method'],x['ratio_label']):(line,x) for line,x in group}
                fl,full=records['Full','Full']
                for method in METHODS:
                    ln,row=records[method,practical]
                    for col in ('clean_full_score','fata_full_score','clean_full_correct','fata_full_correct'):
                        assert row[col]==full[col]
                    for role in ('clean_full','fata_full','clean_compressed','fata_compressed'):
                        assert (number(row[role+'_score'])>0)==boolean(row[role+'_correct'])
                    cf,af,cc,ac=(boolean(row[c]) for c in ('clean_full_correct','fata_full_correct','clean_compressed_correct','fata_compressed_correct'))
                    nfull,k,tiles=(int(row[c]) for c in ('N_full','K_actual','tile_count'))
                    assert nfull==256*tiles and k==round(nfull*float(row['retention_ratio']))
                    sid='|'.join(['InternVL3.5-8B-HF','InternVL_V5','FATA',ds,method,practical])
                    pairs[method].append({'model':'InternVL3.5-8B-HF','series':'InternVL_V5',
                        'attack':'FATA','dataset':ds,'compressor':method,'budget':practical,
                        'setting_id':sid,'sample_id':row['image_id'],'sample_index':index,'seed':row['seed'],
                        'clean_full_score':number(row['clean_full_score']),
                        'attack_full_score':number(row['fata_full_score']),
                        'clean_compressed_score':number(row['clean_compressed_score']),
                        'attack_compressed_score':number(row['fata_compressed_score']),
                        'clean_full_correct':int(cf),'attack_full_correct':int(af),
                        'clean_compressed_correct':int(cc),'attack_compressed_correct':int(ac),
                        'denominator_member':int(cf and af),'numerator_member':int(cf and af and not ac),
                        'N_full':nfull,'K_actual':k,'tile_count':tiles,'status':'success',
                        'clean_full_raw':row['clean_full_raw'],'attack_full_raw':row['fata_full_raw'],
                        'clean_compressed_raw':row['clean_compressed_raw'],
                        'attack_compressed_raw':row['fata_compressed_raw'],
                        'reference_answer':row['reference_answer'],'question':row['question'],
                        'source_file':path.relative_to(self.root).as_posix(),'source_row':ln,'full_source_row':fl})
            for method,pp in pairs.items():
                n=sum(x['numerator_member'] for x in pp);d=sum(x['denominator_member'] for x in pp)
                old=next(x for x in saved if x['Dataset']==ds and x['Compressor']==method)
                assert n==int(old['Numerator_CF_and_AF_and_not_AP']) and d==int(old['Denominator_CF_and_AF'])
                rel=f'paired_records/internvl/{method}_{ds}.csv'
                write_csv(self.out/rel,pp);self.pair_files.append(rel)
                cell={'model':'InternVL3.5-8B-HF','series':'InternVL_V5','attack':'FATA',
                    'dataset':ds,'compressor':method,'budget':practical,'setting_id':pp[0]['setting_id'],
                    'sample_count':len(pp),'cbr_numerator':n,'cbr_denominator':d,'cbr_percent':percent(n,d),
                    'paired_records':rel,'paired_records_sha256':sha(self.out/rel),'source_sha256':sha(path),
                    'evidence':'recomputed_sample_records'}
                self.cells.append(cell)
                self.log(f'CELL {cell["setting_id"]} samples={len(pp)} numerator={n} denominator={d} CBR={cell["cbr_percent"]:.10f}%')

    def tables(self):
        table2=[]
        for attack,series,methods in [('Base (Attn.-only)','ablation_attn_only',METHODS),
            ('CAA','CAA_eps2',None),('CAGE','CAGE',None),('FATA','FATA',None)]:
            ag=self.aggregate(series,methods)
            table2.append({'Attack':attack,'Verified_CBR_percent':ag['cbr_percent'],
                'Display_1dp':display(ag['cbr_percent'],1),'Setting_count':ag['setting_count'],
                'Numerator_sum':ag['numerator_sum'],'Denominator_sum':ag['denominator_sum'],
                'Pooled_CBR_percent':ag['pooled_percent'],'series':series,
                'source_experiment_id':series})
        table3=[]
        for variant,series,methods in [
            ('Attention-only','ablation_attn_only',METHODS),
            ('Semantic-only','ablation_sem_only',METHODS),
            ('FATA Full','FATA',None)]:
            ag=self.aggregate(series,methods)
            table3.append({'Variant':variant,'Verified_CBR_percent':ag['cbr_percent'],
                'Display_1dp':display(ag['cbr_percent'],1),'Setting_count':ag['setting_count'],
                'Numerator_sum':ag['numerator_sum'],'Denominator_sum':ag['denominator_sum'],
                'Pooled_CBR_percent':ag['pooled_percent'],'series':series,
                'source_experiment_id':series})
        write_csv(self.out/'table2_verified.csv',table2)
        write_csv(self.out/'table3_verified.csv',table3)
        grid_results={}
        for table,series in [('table5','Qwen_V6'),('table7','InternVL_V5')]:
            grid=[];exact=[]
            for method in METHODS:
                row={'Compressor':method}
                for ds in DATASETS:
                    c=next(x for x in self.cells if x['series']==series and x['dataset']==ds and x['compressor']==method)
                    row[ds]=display(c['cbr_percent'],2)
                    exact.append({**c,'Display_2dp':display(c['cbr_percent'],2)})
                grid.append(row)
            grid.append({'Compressor':'Average',**{ds:display(statistics.fmean(x['cbr_percent'] for x in exact if x['dataset']==ds),2) for ds in DATASETS}})
            write_csv(self.out/(table+'_counts.csv'),exact)
            write_csv(self.out/(table+'_verified.csv'),grid)
            grid_results[table]=grid
        self.table2,self.table3,self.grid_results=table2,table3,grid_results
        write_csv(self.out/'table2_counts.csv',[x for x in self.cells if x['series'] in ('ablation_attn_only','CAA_eps2','CAGE','FATA')])
        write_csv(self.out/'table3_counts.csv',[x for x in self.cells if x['series'] in ('ablation_attn_only','ablation_sem_only','FATA')])
        for x in table2:
            self.log(f'TABLE2 {x["Attack"]} CBR={x["Verified_CBR_percent"]:.10f}% display={x["Display_1dp"]}% settings={x["Setting_count"]} source_experiment_id={x["source_experiment_id"]} numerator_sum={x["Numerator_sum"]} denominator_sum={x["Denominator_sum"]}')
        for x in table3:
            self.log(f'TABLE3 {x["Variant"]} CBR={x["Verified_CBR_percent"]:.10f}% display={x["Display_1dp"]}% settings={x["Setting_count"]} source_experiment_id={x["source_experiment_id"]} numerator_sum={x["Numerator_sum"]} denominator_sum={x["Denominator_sum"]}')

    def finish(self):
        self.tables()
        write_csv(self.out/'counts_by_setting.csv',self.cells)
        write_csv(self.out/'source_manifest.csv',list(self.source_records.values()))
        write_csv(self.out/'source_exclusions.csv',self.exclusions)
        write_csv(self.out/'historical_git_objects.csv',self.hash_checks)
        overview={'generated_utc':self.started,'source_root':self.root.as_posix(),
            'original_commit':OLD_COMMIT,'setting_count':len(self.cells),
            'paired_record_files':len(self.pair_files),'paired_record_rows':sum(x['sample_count'] for x in self.cells if x.get('paired_records')),
            'qwen_verified_integer_settings':16,'source_file_count':len(self.source_records),
            'selection_id':'paper_adopted_20261110',
            'table2':self.table2,'table3':self.table3,
            'settings':self.cells,'no_new_model_inference':True}
        (self.out/'results.json').write_text(json.dumps(overview,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        self.log('SOURCE_CHECKS duplicate_sample_keys=0 nonfinite_scores=0 archived_count_mismatches=0')
        self.log(f'OUTPUT setting_count={len(self.cells)} paired_files={len(self.pair_files)} paired_rows={overview["paired_record_rows"]} qwen_integer_settings=16')
        self.log('COMPLETED result records exported')
        (self.out/'recompute.log').write_text('\n'.join(self.logs)+'\n',encoding='utf-8')
        return overview


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source-root',required=True)
    parser.add_argument('--history-repo')
    parser.add_argument('--git',default='git')
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    run=Recovery(args)
    run.log('RUN '+run.started)
    run.log('SCRIPT_SHA256 '+sha(__file__))
    run.log('ORIGINAL_GIT_COMMIT '+OLD_COMMIT)
    run.main_llava()
    run.qwen()
    run.internvl()
    run.finish()


if __name__=='__main__':
    main()
