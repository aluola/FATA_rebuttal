"""Independently check the exported evidence against source files and hashes."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
import statistics
from datetime import datetime, timezone


def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--source-root',type=Path)
    args=p.parse_args()
    root=args.bundle.resolve()
    result=json.loads((root/'results.json').read_text(encoding='utf-8'))
    cells=rows(root/'counts_by_setting.csv')
    seen=set();total=0;source_cache={};log=[]
    def message(s):
        print(s,flush=True);log.append(s)
    for cell in cells:
        key=cell['setting_id']
        assert key not in seen
        seen.add(key)
        n=int(cell['cbr_numerator']);d=int(cell['cbr_denominator'])
        assert 0<=n<=d<=int(cell['sample_count'])
        assert abs(100*n/d-float(cell['cbr_percent']))<1e-10
        rel=cell.get('paired_records')
        if not rel:
            assert cell['evidence']=='original_git_integer_counts'
            continue
        file=root/rel
        assert digest(file)==cell['paired_records_sha256']
        rr=rows(file)
        assert len(rr)==int(cell['sample_count'])
        assert len({x['sample_id'] for x in rr})==len(rr)
        actual_n=actual_d=0
        for row in rr:
            assert row['setting_id']==key
            dn,nm=int(row['denominator_member']),int(row['numerator_member'])
            assert dn in (0,1) and nm in (0,1) and nm<=dn
            actual_n+=nm;actual_d+=dn
            if args.source_root is not None:
                source=args.source_root/row['source_file']
                if source not in source_cache:
                    source_cache[source]=rows(source)
                raw=source_cache[source][int(row['source_row'])-2]
                if row['model'].startswith('LLaVA'):
                    clean_source=args.source_root/row['clean_source_file']
                    if clean_source not in source_cache:
                        source_cache[clean_source]=rows(clean_source)
                    clean=source_cache[clean_source][int(row['clean_source_row'])-2]
                    assert raw['Image_ID']==clean['Image_ID']==row['sample_id']
                    fields=[(clean,'Clean_K576','clean_full_score'),
                            (raw,row['attack']+'_K576','attack_full_score'),
                            (clean,'Clean_K'+row['budget'],'clean_compressed_score'),
                            (raw,row['attack']+'_K'+row['budget'],'attack_compressed_score')]
                else:
                    assert raw['image_id']==row['sample_id'] and raw['status']=='success'
                    fields=[(raw,'clean_full_score','clean_full_score'),
                            (raw,'fata_full_score','attack_full_score'),
                            (raw,'clean_compressed_score','clean_compressed_score'),
                            (raw,'fata_compressed_score','attack_compressed_score')]
                for original,source_col,export_col in fields:
                    assert float(original[source_col])==float(row[export_col])
        assert (n,d)==(actual_n,actual_d)
        total+=len(rr)
    assert total==result['paired_record_rows']
    message(f'PAIRED_RECORDS files={sum(bool(x.get("paired_records")) for x in cells)} rows={total} duplicate_setting_keys=0 source_value_mismatches=0')
    for row in rows(root/'historical_git_objects.csv'):
        file=root/'evidence/original_release'/row['path']
        data=file.read_bytes()
        assert digest(file)==row['sha256']
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_blob']
    q=rows(root/'evidence/original_release/results/paper/qwen35/QWEN35_4COMP_CBR_CELL_AUDIT.csv')
    for row in q:
        cell=next(x for x in cells if x['series']=='Qwen_V6' and x['dataset']==row['dataset'] and x['compressor']==row['method'])
        assert int(row['N_blind_practical'])==int(cell['cbr_numerator'])
        assert int(row['N_stealth'])==int(cell['cbr_denominator'])
        assert int(row['N_blind_practical'])+int(row['N_practical_correct_on_stealth'])==int(row['N_stealth'])
        assert f'{float(cell["cbr_percent"]):.2f}'==f'{float(row["CBR_display_2dp"]):.2f}'
    message('QWEN_INTEGER_COUNTS cells=16 git_blob_hashes=verified archived_count_mismatches=0')
    if args.source_root is not None:
        for row in rows(root/'source_manifest.csv'):
            source=Path(row['source_path'])
            assert source.exists() and digest(source)==row['sha256']
        message(f'ORIGINAL_INPUTS files={len(rows(root/"source_manifest.csv"))} sha256_changes=0')
    expected_display={'Base (Attn.-only)':'32.9','CAA':'15.7','CAGE':'43.1','FATA':'22.1'}
    for row in rows(root/'table2_verified.csv'):
        assert row['Display_1dp']==expected_display[row['Attack']]
        group=[x for x in cells if x['series']==row['series'] and (row['series']!='ablation_attn_only' or x['compressor']!='DivPrune')]
        assert len(group)==int(row['Setting_count'])
        assert abs(statistics.fmean(float(x['cbr_percent']) for x in group)-float(row['Verified_CBR_percent']))<1e-10
        message(f'TABLE2 {row["Attack"]} CBR={row["Display_1dp"]}% settings={len(group)} verified')
    for row in rows(root/'table3_verified.csv'):
        group=[x for x in cells if x['series']==row['series']]
        assert len(group)==int(row['Setting_count'])
        assert abs(statistics.fmean(float(x['cbr_percent']) for x in group)-float(row['Verified_CBR_percent']))<1e-10
        message(f'TABLE3 {row["Variant"]} CBR={row["Display_1dp"]}% settings={len(group)} source_experiment_id={row["source_experiment_id"]} verified')
    message(f'ALL_CHECKS_PASSED settings={len(cells)} paired_rows={total} archived_qwen_cells=16')
    (root/'verification.log').write_text('\n'.join(log)+'\n',encoding='utf-8')
    receipt={'verified_utc':datetime.now(timezone.utc).isoformat(),'passed':True,
        'setting_count':len(cells),'paired_record_rows':total,'qwen_integer_settings':16,
        'verified_against_original_inputs':args.source_root is not None,
        'recompute_log_sha256':digest(root/'recompute.log'),
        'counts_by_setting_sha256':digest(root/'counts_by_setting.csv')}
    (root/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
