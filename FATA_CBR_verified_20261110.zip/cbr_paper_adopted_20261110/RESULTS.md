# 论文 CBR 结果

表 2、3、5、7 最终采用的结果、逐设置计数、配对记录与本次运行日志。

## 表 2

| 攻击 | CBR (%) | 论文显示 (%) | 设置数 |
|---|---:|---:|---:|
| Base (Attn.-only) | 32.8581353508 | 32.9 | 16 |
| CAA | 15.6871941375 | 15.7 | 20 |
| CAGE | 43.1002556459 | 43.1 | 20 |
| FATA | 22.0994184587 | 22.1 | 20 |

FATA 与 CAA 的差值：**6.4122243212 个百分点**。

## 表 3

| 变体 | CBR (%) | 论文显示 (%) | 设置数 |
|---|---:|---:|---:|
| Attention-only | 32.8581353508 | 32.9 | 16 |
| Semantic-only | 14.4795112732 | 14.5 | 16 |
| FATA Full | 22.0994184587 | 22.1 | 20 |

## 表 5：Qwen3.5-9B

| 压缩器 | TextVQA-Open | VQAv2-Open | ScienceQA-MC | VQAv2-MC |
|---|---:|---:|---:|---:|
| VisionZIP | 56.58 | 44.70 | 53.28 | 35.85 |
| VisPruner | 33.79 | 34.66 | 40.79 | 31.66 |
| FlowCut | 85.37 | 48.83 | 53.07 | 37.21 |
| PruMerge | 66.67 | 41.13 | 46.20 | 33.02 |
| Average | 60.60 | 42.33 | 48.34 | 34.43 |

## 表 7：InternVL3.5-8B-HF

| 压缩器 | TextVQA-Open | VQAv2-Open | ScienceQA-MC | VQAv2-MC |
|---|---:|---:|---:|---:|
| VisionZIP | 62.18 | 27.99 | 41.39 | 23.00 |
| VisPruner | 72.48 | 36.07 | 41.18 | 23.54 |
| FlowCut | 67.64 | 36.61 | 43.88 | 26.57 |
| PruMerge | 60.12 | 23.96 | 37.55 | 21.92 |
| Average | 65.61 | 31.16 | 41.00 | 23.76 |

## 结果文件

- `recompute.log`：本次实际计算日志。
- `counts_by_setting.csv`：124 项设置的分子、分母及结果。
- `table2_counts.csv`、`table3_counts.csv`、`table5_counts.csv`、`table7_counts.csv`：各表对应计数。
- `table_source_selection.csv`：表格条目与最终采用数据的对应记录。
- `paired_records/`：108 个文件，共 107,942 条配对记录。
- `evidence/original_release/`：原始 Qwen 整数计数与 CAA 汇总记录。
- `source_manifest.csv`、`historical_git_objects.csv`、`SHA256SUMS`：来源与文件哈希。
- `verification.log`、`verification.json`：独立核验记录。
- `recompute_paper_cbr.py`、`verify_records.py`：重复执行入口。
